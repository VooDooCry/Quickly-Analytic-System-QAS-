import time
import customtkinter as ctk
from tkinter import *
import psutil
import shutil
from psutil._common import bytes2human
import os
import platform
from datetime import datetime
import ctypes
import GPUtil
import speedtest
from pythonping import ping
import winshell
import threading
import queue

ctk.set_default_color_theme("dark-blue")
ctypes.windll.shcore.SetProcessDpiAwareness(True)


class ToplevelWindow(ctk.CTkToplevel):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.geometry("350x400")
        self.title("Скорость интернета")
        self.label = ctk.CTkLabel(self, text="Производится спидтест, подождите...")
        self.label.pack(padx=20, pady=20)
        self.label2 = ctk.CTkLabel(self, text="", font=("Arial", 20))
        self.label2.pack(padx=20, pady=35)
        self.label3 = ctk.CTkLabel(self, text="", font=("Arial", 20))
        self.label3.pack(padx=20, pady=38)
        self.label4 = ctk.CTkLabel(self, text="", font=("Arial", 20))
        self.label4.pack(padx=20, pady=41)
        self.queue = queue.Queue()
        self.run_speedtest()
        self.after(100, self.update_labels)

    def run_speedtest(self):
        def perform_speedtest():
            st = speedtest.Speedtest()
            st.get_best_server()
            download_speed = st.download() / 10 ** 6
            upload_speed = st.upload() / 10 ** 6
            response_list = ping('8.8.8.8', verbose=True)
            self.queue.put(("SpeedTest Results", f"Скорость загрузки: {round(download_speed, 2)} Mbps ",
                            f"Скорость выгрузки: {round(upload_speed, 2)} Mbps", f"Ping: {response_list.rtt_avg_ms} "))

        thread = threading.Thread(target=perform_speedtest)
        thread.start()
        thread.join()

    def update_labels(self):
        try:
            results = self.queue.get_nowait()
            self.label.configure(text=results[0])
            self.label2.configure(text=results[1])
            self.label3.configure(text=results[2])
            self.label4.configure(text=results[3])
        except queue.Empty:
            pass
        self.after(100, self.update_labels)


class ToplevelWindow2(ctk.CTkToplevel):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.geometry("400x550")
        self.title("Информация об устройстве")
        self.Pl_label = ctk.CTkLabel(self, text="Производится вычисление, подождите...")
        self.Pl_label.pack(padx=20, pady=18)
        self.Pl_label2 = ctk.CTkLabel(self, text="", font=("Arial", 12))
        self.Pl_label2.pack(padx=20, pady=21)
        self.Pl_label3 = ctk.CTkLabel(self, text="", font=("Arial", 12))
        self.Pl_label3.pack(padx=20, pady=23)
        self.Pl_label4 = ctk.CTkLabel(self, text="", font=("Arial", 12))
        self.Pl_label4.pack(padx=20, pady=25)
        self.Pl_label5 = ctk.CTkLabel(self, text="", font=("Arial", 12))
        self.Pl_label5.pack(padx=20, pady=27)
        self.Pl_label6 = ctk.CTkLabel(self, text="", font=("Arial", 12))
        self.Pl_label6.pack(padx=20, pady=29)
        self.Pl_label7 = ctk.CTkLabel(self, text="", font=("Arial", 12))
        self.Pl_label7.pack(padx=20, pady=31)
        self.queue = queue.Queue()
        self.retrieve_device_info()
        self.after(100, self.update_labels)

    def retrieve_device_info(self):
        def gather_info():
            gpus = GPUtil.getGPUs()
            gpu_info = gpus[0].name if gpus else 'GPU не найдена'
            info = (
                "Информация об устройстве",
                f'Архитектура: {platform.architecture()}',
                f'Процессор: {platform.machine()}',
                f'Имя компьютера: {platform.node()}',
                f'Windows: {platform.platform()}',
                f'Процессор: {platform.processor()}',
                f'GPU: {gpu_info}'
            )
            self.queue.put(info)

        thread = threading.Thread(target=gather_info)
        thread.start()
        thread.join()

    def update_labels(self):
        try:
            info = self.queue.get_nowait()
            self.Pl_label.configure(text=info[0])
            self.Pl_label2.configure(text=info[1])
            self.Pl_label3.configure(text=info[2])
            self.Pl_label4.configure(text=info[3])
            self.Pl_label5.configure(text=info[4])
            self.Pl_label6.configure(text=info[5])
            self.Pl_label7.configure(text=info[6])
        except queue.Empty:
            pass
        self.after(100, self.update_labels)


class SettingsPage(ctk.CTkToplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.parent = parent
        self.setup_ui()
        self.title("Настройки")
        self.iconbitmap("word_logo_icon_181285 (1).ico")
        self.geometry("400x350")

    def setup_ui(self):
        self.theme_label = ctk.CTkLabel(self, text="Тема:")
        self.theme_label.pack(pady=10)
        self.theme_option = ctk.CTkOptionMenu(self, 2, command=self.change_theme, values=["Cветлая", "Тёмная"])
        self.theme_option.set("Тёмная")
        self.theme_option.pack()

        self.opacity_label = ctk.CTkLabel(self, text="Прозрачность окна:")
        self.opacity_label.pack(pady=10)
        self.opacity_slider = ctk.CTkSlider(self, from_=0, to=1, command=self.change_opacity)
        self.opacity_slider.pack()

        self.save_button = ctk.CTkButton(self, text="Сохранить настройки", command=self.save_settings)
        self.save_button.pack(pady=20)

    def change_theme(self, theme):
        App.update_theme(theme)

    def change_opacity(self, opacity):
        self.parent.attributes("-alpha", opacity)

    def save_settings(self):
        SettingsPage.destroy(self)


def LightTheme():
    ctk.set_appearance_mode("light")


def DarkTheme():
    ctk.set_appearance_mode("dark")


class App(ctk.CTk):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.minimize_to_tray = None
        self.toplevel_window2 = None
        self.toplevel_window = None
        self.CFrame3 = None
        self.CFrame2 = None
        self.CFrame = None
        self.t1 = None
        self.t2 = None
        self.ch = None
        self.new_window = None
        self.Theme_button = None
        self.butc = None
        self.sc1 = None
        self.back_button = None
        self.back_frame = None
        self.settings_label = None
        self.title("QAS")
        self.geometry("1280x720")
        self.resizable(False, False)
        myappid = 'mycompany.myproduct.subproduct.version'
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(myappid)
        self.iconbitmap("word_logo_icon_181285 (1).ico")

        def hide():
            self.progressbar3.place(x=3200, y=3444)
            self.progressbar3.update()

        def button_event():
            templ = "%-17s%8s   %8s   %8s    %5s%%%9s %s"
            templ2 = "%-17s %8s %8s   %8s %5s%%%9s     %s"
            templ4 = "%-17s %8s %8s  %8s %5s%%%8s     %s"
            templ3 = "%-17s  %8s  %8s   %8s   %5s%% %9s    %s"
            disk1.configure(text=(templ % ("Disk", "Total", "Used", "Free", "Use", "Type  ", "Mount")))

            for part in psutil.disk_partitions(all=False):
                if os.name == 'nt':
                    if part.fstype == "NTFS":
                        disk2.configure(text='')
                        disk2.update()
                        hide()
                    else:
                        usage = psutil.disk_usage(part.mountpoint)
                        b1 = bytes2human(usage.percent)
                        b2 = int(str(b1)[:-3]) / 100
                        self.progressbar3.set(b2)
                        self.progressbar3.place(x=420, y=96)
                        disk2.configure(text=(templ3 % (
                            part.device,
                            bytes2human(usage.total),
                            bytes2human(usage.used),
                            bytes2human(usage.free),
                            int(usage.percent),
                            part.fstype,
                            part.mountpoint)))
                        disk2.update()
            self.after(5000, button_event)

            for part in psutil.disk_partitions(all=False)[1:2]:
                if os.name == 'nt':
                    if 'cdrom' in part.opts or part.fstype == '':
                        continue
                usage = psutil.disk_usage(part.mountpoint)
                b1 = bytes2human(usage.percent)
                b2 = int(str(b1)[:-3]) / 100
                self.progressbar.set(b2)
                self.progressbar.place(x=420, y=70)
                disk4.configure(text=(templ2 % (
                    part.device,
                    bytes2human(usage.total),
                    bytes2human(usage.used),
                    bytes2human(usage.free),
                    int(usage.percent),
                    part.fstype,
                    part.mountpoint)))
                disk4.update()

            for part in reversed(psutil.disk_partitions(all=False)):
                if os.name == 'nt':
                    if 'cdrom' in part.opts or part.fstype == '':
                        continue
                usage = psutil.disk_usage(part.mountpoint)
                b3 = bytes2human(usage.percent)
                b4 = int(str(b3)[:-3]) / 100
                self.progressbar2.set(b4)
                self.progressbar2.place(x=420, y=45)
                disk3.configure(text=(templ4 % (
                    part.device,
                    bytes2human(usage.total),
                    bytes2human(usage.used),
                    bytes2human(usage.free),
                    int(usage.percent),
                    part.fstype,
                    part.mountpoint)))
                disk3.update()

        def Ram_update():
            varible = 'RAM'
            ram_info = psutil.virtual_memory()
            self.RAM_label.configure(
                text=f"{varible}            Total: {ram_info.total / 1024 / 1024 / 1024:.2f} GB             Available: {ram_info.available / 1024 / 1024 / 1024:.2f} GB             Used: {ram_info.used / 1024 / 1024 / 1024:.2f} GB           Percentage usage: {ram_info.percent}%")
            self.after(1000, Ram_update)
            self.RAM_label.update()

        def GPU_update():
            gpus = GPUtil.getGPUs()
            list_gpus = []
            for gpu in gpus:
                gpu_load = f"{gpu.load * 100}%"
                gpu_free_memory = f"{gpu.memoryFree}MB"
                gpu_used_memory = f"{gpu.memoryUsed}MB"
                gpu_temperature = f"{gpu.temperature} C"
                list_gpus.append((gpu_load, gpu_free_memory, gpu_used_memory, gpu_temperature))
                self.GPU_label.configure(
                    text=f'    GPU            Load: {gpu_load}             Free: {gpu_free_memory}             Used: {gpu_used_memory}             Temp: {gpu_temperature}')
            self.after(5000, GPU_update)
            self.GPU_label.update()

        def update_time():
            cttime.configure(text=f"{datetime.now():%H:%M:%S}")
            self.after(100, update_time)
            cttime.update()

        def update_date():
            current_date = datetime.now()
            ctdate.configure(text="{}.{}.{}".format(current_date.day, current_date.month, current_date.year))
            self.after(100, update_date)
            ctdate.update()

        def LightTheme():
            ctk.set_appearance_mode("light")
            ctk.set_default_color_theme("blue")
            disk1.configure(text_color='black')
            cttime.configure(text_color='black')
            ctdate.configure(text_color='black')
            self.CFrame.configure(fg_color='#f2f3f4')
            self.CFrame2.configure(fg_color='#f2f3f4')
            self.CFrame3.configure(fg_color='#f2f3f4')
            self.CFrame.update()
            self.CFrame2.update()
            self.CFrame3.update()
            self.t1.configure(text_color='black')
            self.t2.configure(text_color='black')
            self.t1.update()
            self.t2.update()

        def DarkTheme():
            ctk.set_appearance_mode("dark")
            ctk.set_default_color_theme("dark-blue")
            disk1.configure(text_color='white')
            cttime.configure(text_color='white')
            ctdate.configure(text_color='white')
            self.t1.configure(text_color='white')
            self.t2.configure(text_color='white')
            self.t1.update()
            self.t2.update()

        def open_settings():
            self.settings_page = SettingsPage(self)

        def sw1():
            if switch_var.get() == 1:
                if self.toplevel_window is None or not self.toplevel_window.winfo_exists():
                    self.toplevel_window = ToplevelWindow(self)
                    time.sleep(20)
                    new_str = ctk.StringVar(value="off")
                    self.Sw1.configure(variable=new_str)
                    self.Sw1.update()
                else:
                    self.toplevel_window.focus()

            else:
                self.Sw1.configure(text="Скорость интернета")

        def sw2():
            if switch_var2.get() == 2:
                if self.toplevel_window2 is None or not self.toplevel_window2.winfo_exists():
                    self.toplevel_window2 = ToplevelWindow2(self)
                    time.sleep(20)
                    new_str = ctk.StringVar(value="off")
                    self.Sw2.configure(variable=new_str)
                    self.Sw2.update()
                else:
                    self.toplevel_window2.focus()
            else:
                self.Sw2.configure(text="Информация о устройстве")

        def host():
            host_button = self.ping_entry.get()
            self.label_canvas.configure(text=ping(host_button, verbose=True))
            self.label_canvas.update()

        def host_clear():
            self.label_canvas.configure(text='')
            self.label_canvas.update()

        def sw3():
            if switch_var3.get() == 3:
                winshell.recycle_bin().empty(confirm=False, show_progress=False, sound=True)
                folder = 'C:/Users/' + os.getlogin() + '/AppData/Local/Temp'
                deleteFileCount = 0
                deleteFolderCount = 0
                for the_file in os.listdir(folder):
                    file_path = os.path.join(folder, the_file)
                    indexNo = file_path.find('\\')
                    itemName = file_path[indexNo + 1:]
                    try:
                        if os.path.isfile(file_path):
                            os.unlink(file_path)
                            print('%s file deleted' % itemName)
                            deleteFileCount = deleteFileCount + 1

                        elif os.path.isdir(file_path):
                            if file_path.__contains__('chocolatey'):
                                continue
                            shutil.rmtree(file_path)
                            print('%s folder deleted' % itemName)
                            deleteFolderCount = deleteFolderCount + 1
                    except Exception as e:
                        print('Access Denied: %s' % itemName)

                print(str(deleteFileCount) + ' files and ' + str(deleteFolderCount) + ' folders deleted.')

            else:
                self.Sw3.configure(text="Очистить корзину и кэш")

        def clear_windows():
            if check_var.get() == 1:
                folder = 'C:/Windows/Temp'
                deleteFileCount = 0
                deleteFolderCount = 0
                for the_file in os.listdir(folder):
                    file_path = os.path.join(folder, the_file)
                    indexNo = file_path.find('\\')
                    itemName = file_path[indexNo + 1:]
                    try:
                        if os.path.isfile(file_path):
                            os.unlink(file_path)
                            print('%s file deleted' % itemName)
                            deleteFileCount = deleteFileCount + 1

                        elif os.path.isdir(file_path):
                            if file_path.__contains__('chocolatey'):
                                continue
                            shutil.rmtree(file_path)
                            print('%s folder deleted' % itemName)
                            deleteFolderCount = deleteFolderCount + 1
                    except Exception as e:
                        print('Access Denied: %s' % itemName)

                print(str(deleteFileCount) + ' files and ' + str(deleteFolderCount) + ' folders deleted.')

            else:
                pass

        def clear_chrome():
            if check_var2.get() == 1:
                cookies = 'C:/Users/' + os.getlogin() + '/AppData/Local/Google/Chrome/User Data/Default/Network/Cookies'
                cookies_jornal = 'C:/Users/' + os.getlogin() + '/AppData/Local/Google/Chrome/User Data/Default/Network/Cookies-journal'
                history = 'C:/Users/' + os.getlogin() + '/AppData/Local/Google/Chrome/User Data/Default/History'
                history_jornal = 'C:/Users/' + os.getlogin() + ('/AppData/Local/Google/Chrome/User '
                                                                'Data/Default/History-journal')
                if os.path.isfile(cookies):
                    os.remove(cookies)
                else:
                    print("Error: %s file not found" % cookies)

                if os.path.isfile(cookies_jornal):
                    os.remove(cookies_jornal)
                else:
                    print("Error: %s file not found" % cookies_jornal)

                if os.path.isfile(history):
                    os.remove(history)
                else:
                    print("Error: %s file not found" % history)

                if os.path.isfile(history_jornal):
                    os.remove(history_jornal)
                else:
                    print("Error: %s file not found" % history_jornal)
            else:
                pass

        self.checkbox_frame = ctk.CTkFrame(self, width=230, height=150)
        self.checkbox_frame.grid(row=0, column=0, padx=20, pady=(20, 0), sticky="nsw")
        self.button = ctk.CTkButton(master=self.checkbox_frame, text="Анализ", command=button_event)
        self.button.place(x=40, y=25, anchor=W)
        self.button2 = ctk.CTkButton(master=self.checkbox_frame, text="Настройки", command=open_settings)
        self.button2.place(x=40, y=75, anchor=W)

        self.main_frame = ctk.CTkTabview(self, width=1230, height=470)
        self.main_frame.grid(padx=20, pady=(10, 0), sticky="nsw")
        self.main_frame.add("Функции")
        self.main_frame.add("Очистка")

        # Функции
        switch_var = ctk.IntVar(value=0)
        self.Sw1 = ctk.CTkRadioButton(self.main_frame.tab("Функции"), command=sw1, variable=switch_var,
                                      text="Скорость интернета",
                                      value=1)
        self.Sw1.place(x=10, y=10)

        switch_var2 = ctk.IntVar(value=0)
        self.Sw2 = ctk.CTkRadioButton(self.main_frame.tab("Функции"), command=sw2, variable=switch_var2,
                                      text="Информация о устройстве",
                                      value=2)
        self.Sw2.place(x=10, y=50)

        switch_var3 = ctk.IntVar(value=0)
        self.Sw3 = ctk.CTkRadioButton(self.main_frame.tab("Функции"), command=sw3, variable=switch_var3,
                                      text="Очистить корзину и кэш",
                                      value=3)
        self.Sw3.place(x=10, y=90)

        self.ping_label = ctk.CTkLabel(self.main_frame.tab("Функции"), text="Pinger", font=("Arial", 20))

        self.ping_label.place(x=980, y=5)
        self.ping_entry = ctk.CTkEntry(self.main_frame.tab("Функции"),
                                       placeholder_text="Введите IP-адресс или доменное имя", width=290)
        self.ping_entry.place(x=870, y=50)
        self.ping_button = ctk.CTkButton(self.main_frame.tab("Функции"), text="Посмотреть", command=host)
        self.ping_button.place(x=870, y=90)
        self.ping_button2 = ctk.CTkButton(self.main_frame.tab("Функции"), text="Очистить", command=host_clear)
        self.ping_button2.place(x=1020, y=90)
        self.label_canvas = ctk.CTkLabel(self.main_frame.tab("Функции"), text='')
        self.label_canvas.place(x=850, y=130)

        # Очистка
        check_var = ctk.IntVar(value=0)
        self.check_1 = ctk.CTkCheckBox(self.main_frame.tab("Очистка"), text="Временные файлы Windows",
                                       command=clear_windows,
                                       variable=check_var, onvalue=1, offvalue=0)
        self.check_1.place(x=10, y=10)

        check_var2 = ctk.IntVar(value=0)
        self.check_2 = ctk.CTkCheckBox(self.main_frame.tab("Очистка"), text="Файлы Google Chrome",
                                       command=clear_chrome,
                                       variable=check_var2, onvalue=1, offvalue=0)
        self.check_2.place(x=10, y=40)

        self.disk_frame = ctk.CTkFrame(self, width=980, height=150)
        self.disk_frame.grid(row=0, column=0, padx=270, pady=(20, 0), sticky="nsw")
        disk1 = ctk.CTkLabel(self.disk_frame, text='', font=("Helvetica", 14), text_color='white')
        disk1.place(x=20, y=20, anchor=W)
        disk2 = ctk.CTkLabel(self.disk_frame, text='', font=("Helvetica", 14))
        disk2.place(x=20, y=100, anchor=W)
        disk3 = ctk.CTkLabel(self.disk_frame, text='', font=("Helvetica", 14))
        disk3.place(x=20, y=50, anchor=W)
        disk4 = ctk.CTkLabel(self.disk_frame, text='', font=("Helvetica", 14))
        disk4.place(x=20, y=75, anchor=W)
        cttime = ctk.CTkLabel(self.disk_frame, text='', font=("Helvetica", 14), text_color='white')
        cttime.place(x=920, y=10)
        ctdate = ctk.CTkLabel(self.disk_frame, text='', font=("Helvetica", 14), text_color='white')
        ctdate.place(x=910, y=30)
        update_time()
        update_date()

        self.progressbar = ctk.CTkProgressBar(master=self.disk_frame, orientation='horizontal', mode='determinate',
                                              progress_color='purple')
        self.progressbar2 = ctk.CTkProgressBar(master=self.disk_frame, orientation='horizontal', mode='determinate',
                                               progress_color='purple')
        self.progressbar3 = ctk.CTkProgressBar(master=self.disk_frame, orientation='horizontal', mode='determinate',
                                               progress_color='purple')
        self.progressbar2.grid_forget()
        self.progressbar.grid_forget()
        self.progressbar3.grid_forget()

        self.RAM_label = ctk.CTkLabel(self, width=630, height=40, text='')
        self.RAM_label.place(x=0, y=670)
        Ram_update()

        self.GPU_label = ctk.CTkLabel(self, width=430, height=40, text='')
        self.GPU_label.place(x=750, y=670)
        GPU_update()

    @staticmethod
    def update_theme(new_theme):
        if new_theme == "Cветлая":
            LightTheme()
        if new_theme == "Тёмная":
            DarkTheme()


if __name__ == "__main__":
    app = App()
    app.mainloop()
